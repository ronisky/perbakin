<?php

return [
    'name' => 'SysModule'
];
