<?php

return [
    'name' => 'Club'
];
