<?php

return [
    'name' => 'Visitor'
];
