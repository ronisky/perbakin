<?php

return [
    'name' => 'FirearmCategory'
];
