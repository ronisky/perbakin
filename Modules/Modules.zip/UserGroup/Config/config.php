<?php

return [
    'name' => 'UserGroup'
];
