<?php

return [
    'name' => 'Sponsorship'
];
