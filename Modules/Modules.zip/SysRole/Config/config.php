<?php

return [
    'name' => 'SysRole'
];
