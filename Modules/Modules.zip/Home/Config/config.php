<?php

return [
    'name' => 'Home'
];
