<?php

return [
    'name' => 'ArticleCategory'
];
