<?php

return [
    'name' => 'SponsorshipCategory'
];
