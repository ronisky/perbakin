<?php

return [
    'name' => 'VisiMisi'
];
