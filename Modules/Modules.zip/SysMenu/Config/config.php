<?php

return [
    'name' => 'SysMenu'
];
