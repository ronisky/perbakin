<?php

return [
    'name' => 'Article'
];
