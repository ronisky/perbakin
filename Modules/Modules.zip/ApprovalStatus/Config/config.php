<?php

return [
    'name' => 'ApprovalStatus'
];
