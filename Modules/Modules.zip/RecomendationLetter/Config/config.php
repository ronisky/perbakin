<?php

return [
    'name' => 'RecomendationLetter'
];
