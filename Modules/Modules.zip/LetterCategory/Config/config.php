<?php

return [
    'name' => 'LetterCategory'
];
